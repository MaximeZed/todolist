#wik-njs-303-skeleton

Simple ExpressJS skeleton.

## Install

    git clone https://github.com/Tronix117/wik-njs-303-skeleton.git
    cd wik-njs-303-skeleton
    npm install

## Usage

    npm start

